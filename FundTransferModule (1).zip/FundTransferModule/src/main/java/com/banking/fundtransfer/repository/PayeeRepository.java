package com.banking.fundtransfer.repository;




import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.banking.fundtransfer.entity.Payee;


@Repository
public interface PayeeRepository extends CrudRepository<Payee, Integer>

{



}
