package com.banking.fundtransfer.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="Login")
public class Login 
{
	
	@Id
	@Column(name="username",length=20)
	private String username;
	
	@Column(name="password", length=20)
	private String password;
	
	@Column(name = "Account_id")
	private int accountId;
	//@OneToOne(mappedBy="login",cascade=CascadeType.ALL)
	//@JoinColumn(name="Account_Id")
	//private Account account;
	
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public String getUsername() 
	{
		return username;
	}
	public void setUsername(String username) 
	{
		this.username = username;
	}
	public String getPassword() 
	{
		return password;
	}
	public void setPassword(String password) 
	{
		this.password = password;
	}
	/*
	@OneToMany(mappedBy="login",cascade=CascadeType.ALL)
	private Set<Account> accountSet;
*/

}
