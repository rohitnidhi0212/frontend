package com.banking.fundtransfer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.banking.fundtransfer.ResponseStatus;
import com.banking.fundtransfer.entity.Payee;
import com.banking.fundtransfer.exceptions.PayeeListEmptyException;
import com.banking.fundtransfer.exceptions.PayeeNotFoundException;
import com.banking.fundtransfer.service.PayeeService;




@CrossOrigin			//CORS
@RestController
@RequestMapping("/payee")
public class PayeeController
{

	@Autowired 
	PayeeService payeeService;
	
//	@PostMapping("/addpayee")
//	public ResponseEntity<Payee> savePayee(@RequestBody Payee payee)
//
//	{
//		ResponseEntity<Payee> responseRef=null;
//	    Payee payee1 = payeeService.addPayee(payee);
//	    responseRef = ResponseEntity.ok(payee1);
//		return responseRef;
//		
//	}
	
	@RequestMapping("/getPayee/{pid}")
	public ResponseEntity <Payee> getPayeeObject(@PathVariable("pid") int payeeId)
	{
		
		Payee payee = null;
		ResponseEntity responseRef=null;
		try {
			payee = payeeService.findPayeeByIdService(payeeId);
			responseRef = ResponseEntity.ok(payee);
			return responseRef;
		} catch (PayeeNotFoundException e) {
			//throw e;
			System.out.println("Payee list is empty ");
			ResponseStatus respStatus = new ResponseStatus();
			respStatus.setMessage(e.getMessage());
			responseRef = ResponseEntity.status(HttpStatus.NOT_FOUND).body(respStatus);
			//return responseRef;
		}
		return responseRef;
		
	}

	
	@GetMapping("/getAllPayee")
	public List<Payee> getAllPayee() {
		List<Payee> payeeList = null;
		try {
			payeeList = payeeService.findAllPayeeService();
			
			
		}
		catch (PayeeListEmptyException e) {
			e.printStackTrace();
		}
		return payeeList;

	}	
}
