package com.banking.fundtransfer.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.banking.fundtransfer.entity.Payee;
import com.banking.fundtransfer.exceptions.PayeeListEmptyException;
import com.banking.fundtransfer.exceptions.PayeeNotFoundException;
import com.banking.fundtransfer.repository.PayeeRepository;
import com.banking.fundtransfer.service.PayeeService;

@Service
public class PayeeServiceImpl implements PayeeService
{
	@Autowired PayeeRepository payeeRepository;
	@Override
	public List<Payee> findAllPayeeService() throws PayeeListEmptyException{
		// TODO Auto-generated method stub
		List<Payee> payeeList = (List<Payee>) payeeRepository.findAll();
		if (payeeList.isEmpty()) {
			throw new PayeeListEmptyException("Payee List is empty! Please add a new payee first");
		}
		else {
			return payeeList;
		}
		
	}

	@Override
	public Payee findPayeeByIdService(int payeeId) throws PayeeNotFoundException {
		// TODO Auto-generated method stub
		Optional<Payee> thePayee = payeeRepository.findById(payeeId);
		if(thePayee.isPresent()) {
			return thePayee.get();
		}
		else {
			throw new PayeeNotFoundException("Payee not found for the given ID");
		}
		
	}

	@Override
	public Payee addPayeeService(Payee PayeeObject) {
		// TODO Auto-generated method stub
		Payee newPayee = payeeRepository.save(PayeeObject);
		return newPayee;
	}
	


}
