package com.banking.fundtransfer.exceptions;

public class PayeeListEmptyException extends Exception 
{

	public PayeeListEmptyException(String message) 
	
	{
		super(message);
		// TODO Auto-generated constructor stub
	}

}
