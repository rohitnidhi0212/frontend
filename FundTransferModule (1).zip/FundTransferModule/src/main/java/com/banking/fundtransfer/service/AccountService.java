package com.banking.fundtransfer.service;


import org.springframework.stereotype.Service;

import com.banking.fundtransfer.entity.Account;


@Service
public interface AccountService 

{

	
public Account saveAccountService(Account AccountObj);
public Account getAccountService(int cif);
} 


