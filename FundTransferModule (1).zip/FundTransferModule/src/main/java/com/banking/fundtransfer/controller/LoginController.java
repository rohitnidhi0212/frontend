package com.banking.fundtransfer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.banking.fundtransfer.entity.Login;
import com.banking.fundtransfer.service.LoginService;

@CrossOrigin
@RestController
@RequestMapping("/login")
public class LoginController 
{
	@Autowired LoginService loginService;
	
	
	@GetMapping("/getLoginDetails/{username}")
	 public ResponseEntity<Login> getLoginDetails(@PathVariable("username") String username)
	{
	 	Login acc = null;
			ResponseEntity responseRef=null;
			try {
				acc = loginService.getLoginService(username);
			
				responseRef = ResponseEntity.ok(acc);
				return responseRef;
			} catch (Exception e) 
			{
				throw e;
				
			}

}
}